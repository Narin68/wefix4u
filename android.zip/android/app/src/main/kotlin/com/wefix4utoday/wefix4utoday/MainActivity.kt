package com.wefix4utoday.wefix4utoday

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
